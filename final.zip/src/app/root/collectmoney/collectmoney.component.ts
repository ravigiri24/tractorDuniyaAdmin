import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collectmoney',
  templateUrl: './collectmoney.component.html',
  styleUrls: ['./collectmoney.component.scss']
})
export class CollectmoneyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
