import { Component, OnInit,ViewChild } from '@angular/core';
import Swal from 'sweetalert2';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute, NavigationExtras, Data } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { ApiService } from "../../services/api.service";
import { SharedataService } from "../../services/sharedata.service";
import { Subject, Observable } from 'rxjs';
import { WebcamImage, WebcamInitError, WebcamUtil } from 'ngx-webcam';
import { ImageCroppedEvent } from 'ngx-image-cropper';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.scss']
})
export class UserprofileComponent implements OnInit {



    updateprofileForm: FormGroup;
    changepassForm: FormGroup;
    
    id= '';
    loading = false;
    forgot_loading = false;
    forgot_submitted = false;
    submitted = false;
    
    profileletterblock= true;
    profileletter = 'S';
    // returnUrl: string;
    invalid_data = false;
    success_data = false;
    success_data_password = false;

    @ViewChild('closebutton_changepwd', { static: false }) closebutton_apic;

    constructor(
        private api: ApiService,
        private formBuilder: FormBuilder,
        private router: Router,
        private share: SharedataService,
        private snackBar: MatSnackBar,
        private routes: ActivatedRoute
        // private authenticationService: AuthenticationService,
        // private alertService: AlertService
    ) {
        // redirect to home if already logged in
        // if (this.authenticationService.currentUserValue) {
        //     this.router.navigate(['/']);
        // }
    }
 staff_rfid:any
    ngOnInit() {
        this.staff_rfid = sessionStorage.getItem('Staff_rfid');
        this.updateprofileForm = this.formBuilder.group({
            staff_fname: ['', Validators.required],
            staff_fathername: [''],
            staff_mobile: [''],
            staff_email: [''],
            user_id: ['', Validators.required],
            user_password: ['', Validators.required],
            staff_address: [''],
            staff_img: [''],
            img_type: [''],
         
        });

       this.get_staff_detail()
      
        this.changepassForm = this.formBuilder.group({
            newpassword: ['', Validators.required],
            prevpassword: ['', Validators.required],
            retypepass: ['', Validators.required]
        });
        this.getprofiledetails();
        // get return url from route parameters or default to '/'
        // this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }
    showNotification(colorName, text, placementFrom, placementAlign) {
        this.snackBar.open(text, '', {
          duration: 2000,
          verticalPosition: placementFrom,
          horizontalPosition: placementAlign,
          panelClass: colorName
        });
      }
img:any
    get_staff_detail(){

        let staff_d={
            "staff_rfid":this.staff_rfid
        }
        this.api.postapi("staff_detail_update",staff_d).subscribe((res:any)=>{

            if(res.status==1){
                 
                  this.updateprofileForm.controls.staff_fname.setValue(res.data.staff_fname)
                  this.updateprofileForm.controls.staff_fathername.setValue(res.data.staff_fathername)
                  this.updateprofileForm.controls.staff_mobile.setValue(res.data.staff_mobile)
                  this.updateprofileForm.controls.staff_email.setValue(res.data.staff_email)
                  this.updateprofileForm.controls.user_id.setValue(res.data.user_id)
                  this.updateprofileForm.controls.user_password.setValue(res.data.user_password)
                  this.updateprofileForm.controls.staff_address.setValue(res.data.staff_address)
   this.img=res.full_img
            }
        })
    }

    onFileChange(event) {
        console.log('onchange fired', event)
        let reader = new FileReader();
        if (event.target.files && event.target.files.length > 0) {
          let file = event.target.files[0];
     
     
          
          reader.readAsDataURL(file);
          reader.onload = () => {
            this.img= reader.result as string
            console.log('reader.result', reader.result)
            console.log('filename', file.name)
            console.log('filetype', file.type)
            var img
            if(file.type=="image/jpeg"){
                img=  reader.result.toString().replace('data:image/jpeg;base64,/', "")
                this.updateprofileForm.controls.img_type.setValue(1) 
            }
            else{
                img=  reader.result.toString().replace('data:image/png;base64,/', "")
                this.updateprofileForm.controls.img_type.setValue(0) 

            }
            this.updateprofileForm.controls.staff_img.setValue(reader.result) 
            console.log("this.doctor_details.profileImage", this.updateprofileForm.value)
          }
        //   const reader1 = new FileReader();
        //   reader1.onload = () => {
        //     this.img = reader1.result as string;
        //     console.log(" this.img", this.img);
        //   }
        //   reader1.readAsDataURL(file)
          
        }
      }

    updateprofile(){
       
        this.updateprofileForm.value.staff_rfid=this.staff_rfid
this.api.postapi("update_staff",this.updateprofileForm.value).subscribe((res:any)=>{

    if(res.status==1){
        this.showNotification('snackbar-success', res.msg, 'top', 'right');
this.img=res.full_img
console.log(" this.img", this.img);
this.share.setchange_name(res.data.staff_fname)
this.share.setchange_image(res.full_img)
this.share.set_session(res.data);
    }
    else{

        this.showNotification('snackbar-danger', res.msg, 'top', 'right');
    }
})


    }
    getprofiledetails(){
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.id = currentUser.id;
        // this.authenticationService.getprofile(this.id)
        //     .pipe(first())
        //     .subscribe(
        //         data => {
        //             // this.router.navigate([this.returnUrl]);
        //             console.log("Get Details",JSON.stringify(data))
        //             //localStorage.setItem('currentUser', JSON.stringify(data));
        //             // var d :any= JSON.stringify(data);
        //             // console.log('data', data.name);                    
        //             // console.log('data name', data.company_name);
                    
        //             this.updateprofileForm.controls['username'].setValue(data.name);
        //             this.updateprofileForm.controls['emailid'].setValue(data.email);
        //             this.updateprofileForm.controls['company'].setValue(data.company_name);
                    
        //             this.profileletter = data.name.substring(0,1)
        //         },
        //         error => {
        //             this.alertService.error(error);
        //             this.loading = false;
        // });
    }
    // convenience getter for easy access to form fields
    get f() { return this.updateprofileForm.controls; }
    get c() { return this.changepassForm.controls; }
    // onSubmit() {
    //     this.submitted = true;

    //     // reset alerts on submit
    //     this.alertService.clear();

    //     // stop here if form is invalid
    //     if (this.updateprofileForm.invalid) {
    //         return;
    //     }

    //     this.loading = true;
    //     this.invalid_data = false;
    //     let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    //     this.id = currentUser.id;
    //     this.authenticationService.updateprofile(this.id, this.f.emailid.value, this.f.username.value, this.f.company.value)
    //         .pipe(first())
    //         .subscribe(
    //             data => {
    //                 // this.router.navigate([this.returnUrl]);
    //                 console.log("Update profile",data.success)
                    
                
    //                 // var response = JSON.stringify(data);    
    //                 if(data.success == "1"){
    //                     this.success_data = true;
    //                     this.loading = false;
    //                     this.submitted = false;    
    //                 }else{
    //                     this.invalid_data = true;
    //                     this.loading = false;
                     
    //                 }
                    
    //                 // this.success_data = false;
    //             },
    //             error => {
    //                 this.alertService.error(error);
    //                 this.loading = false;
    //             });
    // }
    // onChangeSubmit(){
    //     this.forgot_submitted = true;

    //     // reset alerts on submit
    //     this.alertService.clear();

    //     // stop here if form is invalid
    //     if (this.changepassForm.invalid) {
    //         return;
    //     }

    //     this.forgot_loading = true;
    //     this.invalid_data = false;
    //     let currentUser = JSON.parse(localStorage.getItem('currentUser'));
    //     this.id = currentUser.id;
    //     this.authenticationService.changepassword(this.id,this.c.newpassword.value, this.c.retypepass.value,this.c.prevpassword.value)
    //         .pipe(first())
    //         .subscribe(
    //             data => {
    //                 // this.router.navigate([this.returnUrl]);
    //                 console.log("Change Password",JSON.stringify(data))
                    
    //                 // var response = JSON.stringify(data);    
    //                 if(data.success == "1"){
    //                     // localStorage.setItem('currentUser', JSON.stringify(data));
    //                     // this.router.navigate(['/dashboard']);
    //                     this.success_data_password = true;
    //                 this.forgot_loading = false;
    //                 this.forgot_submitted = false;
    //                 this.closebutton_apic.nativeElement.click();
    //                 }else{
    //                     this.invalid_data = true;
    //                     this.loading = false;
                        
    //                 }
                    
    //             },
    //             error => {
    //                 this.alertService.error(error);
    //                 this.loading = false;
    //             });
    // }



}
